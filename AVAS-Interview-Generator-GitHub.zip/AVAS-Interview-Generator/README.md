# AVAS — Interview Question Generator

> AI-powered interview preparation interface for generating role-based interview questions.

## Overview

**AVAS (Interview Question Generator)** is a responsive web application designed to help candidates practice interview questions based on their job role, experience level, number of questions, and question type.

The current implementation is a lightweight, browser-based HTML/CSS/JavaScript application with no external backend required to run the included demo.

## Features

- ✦ **Role-based questions** — Enter any job role, such as Frontend Developer.
- ⚡ **Experience levels** — Fresher, 2–4 Years, and 5+ Years.
- 🔢 **Custom question count** — Generate 5, 10, or 15 questions.
- 🎯 **Multiple question types** — Technical, Behavioral, Situational, or Mixed.
- 🚀 **Instant generation** — Questions appear directly in the interface.
- 📱 **Responsive UI** — Layout adapts for desktop, tablet, and mobile screens.
- 🌌 **Modern dark interface** — Gradient-based visual design with glassmorphism-style cards.
- 👥 **Team section** — Includes the AVAS Empire team presentation area.

## How It Works

1. Select or enter a **Job Role**.
2. Choose an **Experience Level**.
3. Select the **Number of Questions**.
4. Choose the **Question Type**.
5. Click **Generate Questions**.
6. AVAS displays the generated questions immediately.

The current version uses predefined JavaScript question templates for Technical, Behavioral, and Situational categories. Mixed mode cycles through those categories.

## Project Structure

```text
AVAS-Interview-Generator/
├── index.html
├── assets/
│   └── screenshots/
│       └── README.md
└── README.md
```

### Main file

- `index.html` — Complete application containing the HTML structure, CSS styling, and JavaScript question-generation logic.

## Screenshots

Add project screenshots to `assets/screenshots/` and reference them here.

### Home / Landing Page

```text
assets/screenshots/home.png
```

![AVAS Home Page](assets/screenshots/home.png)

### Question Generator

```text
assets/screenshots/generator.png
```

![AVAS Question Generator](assets/screenshots/generator.png)

> **Note:** The screenshot placeholders are included so the repository is ready for screenshots. Replace them with actual PNG/JPG screenshots of the running application.

## Running Locally

### Option 1 — Open directly

1. Download or clone the repository.
2. Open `index.html` in a modern web browser.
3. Use the generator.

### Option 2 — Run with a local server

If Python is installed:

```bash
python -m http.server 8000
```

Then open:

```text
http://localhost:8000
```

## GitHub Pages

Because the project is a static HTML/CSS/JavaScript application, it can be hosted using **GitHub Pages**.

After pushing the project to GitHub:

1. Open the repository.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select the `main` branch and `/ (root)`.
5. Save the settings.
6. GitHub will provide the published Pages URL.

## Technology Stack

- **HTML5**
- **CSS3**
- **JavaScript**
- **Google Fonts** — DM Sans and Space Grotesk

## Current Question Logic

The application contains templates for:

- **Technical**
- **Behavioral**
- **Situational**
- **Mixed** mode

The selected role and experience level are incorporated into the displayed questions.

## Future Scope

Possible improvements for a future version:

- Connect the generator to a real AI API.
- Generate questions dynamically instead of using fixed templates.
- Add model-generated answers and evaluation.
- Add difficulty levels.
- Add interview sessions and progress tracking.
- Add question bookmarking and history.
- Add authentication and user profiles.
- Add downloadable interview reports.
- Add speech-based mock interviews.

## Team

### AVAS Empire

- Ashish
- Vinayak
- Ayush
- Sarthak

> Building intelligent solutions for a smarter tomorrow.

## Hackathon Demo

For a hackathon presentation, demonstrate the application in this order:

1. Open the AVAS landing page.
2. Explain the problem: interview preparation can be generic and difficult to personalize.
3. Enter a job role.
4. Select experience level and question type.
5. Generate questions.
6. Show how different settings change the generated output.
7. Explain the current architecture and future AI integration.
8. Conclude with the AVAS Empire vision.

## License

This repository does not currently specify an open-source license. Add a license if you want to define how others may use, modify, and distribute the project.
