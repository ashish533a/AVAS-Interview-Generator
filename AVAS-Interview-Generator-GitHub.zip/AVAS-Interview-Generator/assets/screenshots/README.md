# Screenshots

Place application screenshots in this folder.

Suggested files:

- `home.png` — Landing page
- `generator.png` — Question generator with generated results
- `mobile.png` — Mobile/responsive view

These images are referenced by the root `README.md`.
